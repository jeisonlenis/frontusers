<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Foundation\Auth\User;

class UsersContoller extends Controller
{
    public function index(Request $request)
    {

    }

    public function store(Request $request)
    {
        $entrada = $request->all();

        User::create($entrada);
        return response()->json(["res" => true, , "mensaje" => "Usuario creado exitosamente"], 200);
    }

    public function show($id)
    {
        $usuario = User::find($id);
        return response()->json($usuario, 200);
    }

    public function update(Request $request, $id)
    {
        $usuario = User::findOrFail($id);

        $entrada = $request->all();
        $usuario->update($entrada);
        return response()->json(["res" => true, , "mensaje" => "Usuario actualizado exitosamente"], 200);
    }

}
