import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';

import { User } from '../../../models/user';
import { UserService } from '../../../services/user.service';

import * as moment from 'moment';
@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css'],
})
export class CreateComponent implements OnInit {
  public myForm: FormGroup;

  public user = new User();

  public tiposdocumento: any[] = [];

  constructor(private fb: FormBuilder, private userService: UserService) {}

  ngOnInit(): void {
    this.tiposdocumento = [
      { nombre: 'CEDULA DE CIUDADANIA', value: 'CC' },
      { nombre: 'CEDULA DE EXTRANJERIA', value: 'CE' },
      { nombre: 'PASAPORTE', value: 'PP' },
    ];
  }

  save(): void {
    this.user.name = this.myForm.value.name;
    this.user.lastname = this.myForm.value.name;
    this.user.username = this.myForm.value.username;
    this.user.email = this.myForm.value.name;
    this.user.fecha_nac = moment(this.myForm.value.name).format('YYYY-MM-DD');

    if (this.myForm) {
      let user: any;
      this.userService.create(this.user).subscribe((data) => {
        user = data;
      });
    }
  }
}
