import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { UsersRoutingModule } from '../users/users.routing';

import { UsersComponent } from './users.component';
import { CreateComponent } from '../users/create/create.component';
import { ListComponent } from '../users/list/list.component';
import { UpdateComponent } from '../users/update/update.component';

@NgModule({
  declarations: [
    UsersComponent,
    CreateComponent,
    ListComponent,
    UpdateComponent,
  ],
  imports: [CommonModule, UsersRoutingModule, ReactiveFormsModule, FormsModule],
})
export class UsersModule {}
