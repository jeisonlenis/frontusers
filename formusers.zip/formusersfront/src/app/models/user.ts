export class User {
  id: string;
  name: string;
  lastname: string;
  username: string;
  tipo_doc: string;
  numero_doc: number;
  fecha_nac: string;
  email: string;
}
