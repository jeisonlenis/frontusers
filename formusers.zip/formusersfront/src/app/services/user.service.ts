import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from '../models/user';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root',
})
export class UserService {
  constructor(public http: HttpClient) {}

  create(user: User): Observable<User> {
    return this.http.post<User>(`${environment.url}`, user);
  }

  findAll(): Observable<User> {
    return this.http.get<User>(`${environment.url}/users`);
  }

  findById(username: string): Observable<User> {
    return this.http.get<User>(`${environment.url}/users/${username}`);
  }

  detele(id: string): Observable<User> {
    return this.http.delete<User>(`${environment.url}/delete/${id}`);
  }
}
